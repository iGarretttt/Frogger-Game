package org.frogger;

import java.io.IOException;

import javax.swing.JFrame;

import org.frogger.ui.Display;

public class Main {
	
	public static void main(String[] args) throws IOException {		
		JFrame frame= new JFrame("Frogger");
		Display game= new Display();	
		frame.add(game);
		frame.setSize(600,480);
      		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
