package org.frogger;

public class Config {

	public static String spritePath = System.getProperty("user.home") + "Frogger/img/";
}
